//
//  avatarMovie.h
//  Project1
//
//  Created by Michele Laramore on 10/31/13.
//  Copyright (c) 2013 Michele Laramore. All rights reserved.
//

#import "baseMovie.h"

@interface avatarMovie : baseMovie

//data member for manipulating production cost data
@property float productionCushionCost;

@end
