//
//  Project1Tests.h
//  Project1Tests
//
//  Created by Michele Laramore on 10/30/13.
//  Copyright (c) 2013 Michele Laramore. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Project1Tests : SenTestCase

@end
