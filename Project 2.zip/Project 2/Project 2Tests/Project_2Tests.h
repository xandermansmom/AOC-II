//
//  Project_2Tests.h
//  Project 2Tests
//
//  Created by Michele Laramore on 11/7/13.
//  Copyright (c) 2013 Michele Laramore. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Project_2Tests : SenTestCase

@end
